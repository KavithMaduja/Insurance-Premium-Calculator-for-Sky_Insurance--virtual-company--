#include<stdio.h>
int vehicle_category,drivers_age,vehicle_age,terrorism_cover_taken,sr_cover_taken,disaster_cover_taken,no_claim_no;
float sum_insured,basic_premium=0,premium=0,discount=0,total_premium=0;

void get_inputs()//j
{
  printf("\n\nVehicle category\n\nCAR/JEEP/SUV\t--> Enter 1\nMOTOR CYCLE\t--> Enter 2\nHEAVY VEHICLES\t--> Enter 3\n\nEnter category: ");
  scanf("%d",&vehicle_category);

  if(vehicle_category!=-99)
  {
      if(vehicle_category!=-98)
      {
        printf("Enter the sum insured:Rs.");
        scanf("%f",&sum_insured);

        printf("Enter age of the person: ");
        scanf("%d", &drivers_age);

        printf("Enter No. of years since vehicle was manufactured:");
        scanf("%d", &vehicle_age);

        printf("Additional covers:\nIs Terrorism cover taken? ");
        scanf("%d", &terrorism_cover_taken);

        printf("Is Strike/riot cover taken? ");
        scanf("%d", &sr_cover_taken);

        printf("Is Natural disaster cover taken? ");
        scanf("%d", &disaster_cover_taken);

        printf("Enter No. of months for 'No claim' deductions: ");
        scanf("%d", &no_claim_no);
      }
  }

}

void find_basic_premium()//h
{
    switch(vehicle_category)
    {
    case 1:
        {
            if(sum_insured <= 5000000)
            {
                basic_premium = sum_insured*0.2; //20%
            }
                else
            {
                basic_premium = sum_insured*0.3; //30%
            }
            break;
        }
    case 2:
        {
            if(sum_insured <= 300000)
            {
                basic_premium = sum_insured*0.05;  //5%
            }
            else
            {
                basic_premium = sum_insured*0.1;  //10%
            }
            break;
        }
    case 3:
        {
            if(sum_insured <= 10000000)
            {
                basic_premium = sum_insured*0.4; //40%
            }
            else
            {
                basic_premium = sum_insured*0.5; //50%
            }
            break;
        }

    }

    premium = basic_premium;

}

void add_age_payment()//m
{
    if(drivers_age<=70 && drivers_age>=51)
    {
        premium=premium+2000;
    }
       else if(drivers_age<=50 && drivers_age>=31)
       {
           premium=premium+3000;
       }
          else if(drivers_age<=30 && drivers_age>=18)
          {
              premium=premium+5000;
          }

}

void add_vehicle_years_payment()//j
{
   if(vehicle_age>20)
   {
     premium=premium+1500;
   }
   else if(vehicle_age>=10 && vehicle_age<=20)
   {
     premium=premium+2500;
   }
   else if(vehicle_age>=0 && vehicle_age<10)
   {
     premium=premium+3000;
   }

}

void add_additionalcover_payments()//h
{
    if(terrorism_cover_taken == 1)
        {
            premium = premium + 2500;
        }
        if(sr_cover_taken == 1)
        {
            premium = premium + 3000;
        }
        if(disaster_cover_taken == 1)
        {
            premium = premium + 2000;
        }

}

void find_deductions()//k
{
  total_premium=premium;

  switch(no_claim_no)
  {
        case 1:
            {   discount=basic_premium*5/100;
                total_premium=total_premium-discount;
                break;
            }
        case 2:
            {
                discount=basic_premium*10/100;
               total_premium=total_premium-discount;
               break;
            }
        case 3:
            {
               discount=basic_premium*15/100;
               total_premium=total_premium-discount;
               break;
            }
        case 4:
            {
               discount=basic_premium*20/100;
               total_premium=total_premium-discount;
               break;
            }
        case 5:
            {
               discount=basic_premium*25/100;
               total_premium=total_premium-discount;
               break;
            }
  }

}

void output_finalpremium_amount()//m
{
printf("\nBasic Premium\t\t =\tRs.%.2f ",basic_premium);
printf("\nPremium Before Deduction =\tRs.%.2f ",premium);
printf("\nDeduction\t\t =\tRs.%.2f",discount);
printf("\nTotal Premium\t\t =\tRs.%.2f",total_premium);
printf("\n\nSky Insurance property.\nCalculation finished.\nNIBM IT.\nTroubleshooting information: 0112244889");
}

void display_menutext()//k
{
    printf("\nWelcome to Sky Insurance Premium Calculator\n");
    printf("___________________________________________\n");
    printf("Start calculation (1)\n");
    printf("Show help\t  (2)\n");
    printf("Exit\t\t  (3)\n");
    printf("___________________________________________\n");
    printf("Enter Your Selection: ");
}


int main()
{
    int menu_selection;

   while(1==1)//menu exit
   {
     display_menutext();
     scanf("%d",&menu_selection);
      if(menu_selection==3)
         {
           break;
         }
         if(menu_selection==2)
         {
           printf("\nHelp:\tTo Stop Calculation & Exit The Program:Enter -99\n\tTo return to Main menu:Enter -98\n");
         }
         if(menu_selection==1)
         {


            while(1==1)//exit by vehicle category
            {
                get_inputs();
                if(vehicle_category==-99)
                    {
                    break;
                    }
                if(vehicle_category==-98)
                    {
                     break;
                    }

                find_basic_premium();
                add_age_payment();
                add_vehicle_years_payment();
                add_additionalcover_payments();
                find_deductions();
                output_finalpremium_amount();
            }
         }

       if(vehicle_category==-99)
            {
              break;
            }
   }

 return 0;
}
